#ifndef SS_H
#define SS_H

void init_shell();
int alloc_check(void *);

#endif